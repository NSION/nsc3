#!/usr/bin/env bash

if [ -z "$1" ]; then
    echo "Usage: ./diagnose.sh <target-domain>"
    exit 1
fi

TARGET_DOMAIN="$1"
PORTS=(443 25204 25205 25206)
TARGET_IP=$(dig +short $TARGET_DOMAIN | tail -n1)

mkdir -p logs
LOGFILE="./logs/diagnostic-$(date +%Y%m%d-%H%M%S).log"

log() { echo -e "$1" | tee -a "$LOGFILE"; }

log "=== SaaS NETWORK DIAGNOSTICS (Linux/macOS TCP-SAFE) ==="
log "Target domain: $TARGET_DOMAIN
"

log "1) DNS CHECK"
if [ -z "$TARGET_IP" ]; then
    log "FAIL: DNS lookup failed"
else
    log "OK: DNS resolved to $TARGET_IP"
fi
log ""

log "2) HTTPS CHECK (443)"
curl -I --silent --max-time 5 https://$TARGET_DOMAIN >/dev/null
if [ $? -ne 0 ]; then
    log "FAIL: HTTPS unreachable"
else
    log "OK: HTTPS reachable"
fi
log ""

log "3) RAW TCP PORT CHECKS (/dev/tcp)"
for p in "${PORTS[@]}"; do
    echo -n "Testing port $p ... " | tee -a "$LOGFILE"
    timeout 5 bash -c "cat < /dev/null > /dev/tcp/$TARGET_DOMAIN/$p" 2>/dev/null
    RET=$?
    if [ $RET -eq 0 ]; then
        log "OPEN"
    elif [ $RET -eq 124 ]; then
        log "TIMEOUT (blocked or filtered)"
    else
        log "CLOSED (connection refused)"
    fi
done
log ""

log "4) TRACEROUTE"
traceroute -n $TARGET_DOMAIN 2>&1 | tee -a "$LOGFILE"
log ""

log "=== DONE ==="
