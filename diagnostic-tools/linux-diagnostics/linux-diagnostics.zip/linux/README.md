# SaaS Network Diagnostics Toolkit (TCP-Safe Version)

Linux version uses /dev/tcp + timeout for reliable port testing.

## Usage (Linux)
chmod +x diagnose.sh
./diagnose.sh my.domain.com

## Usage (Windows)
powershell -ExecutionPolicy Bypass -File .\diagnose.ps1 my.domain.com
