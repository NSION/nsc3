# SaaS Network Diagnostics Toolkit (Parametric Version)

This version supports passing the target domain as a CLI argument.

## Usage (Linux)
chmod +x diagnose.sh  
./diagnose.sh my.domain.com

## Usage (Windows)
powershell -ExecutionPolicy Bypass -File .\diagnose.ps1 my.domain.com
